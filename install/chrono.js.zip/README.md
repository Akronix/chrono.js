# Chrono.js
This is a very simple stopwatch programmed in javascript.  
I started it for a web applications course, but I have often found it useful so I think it's worthy to be published here.

It can be run either in a browser, in a smartphone (it detects touch events from tactile screen) or it can even be installed in your computer.

It supports two languages: index.html for english and index-es.html for spanish.
